﻿using UnityEngine;
using UnityEngine.InputSystem;

public class FPSController : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 2f;
    public float gravity = 30f;
    public float rotationSpeed = 10f; // Rychlost otáčení postavy

    [Header("Look (RE Style)")]
    public float mouseSensitivity = 0.05f;
    public Transform cameraPivot;
    public float minPitch = -40f;
    public float maxPitch = 40f;

    private float _pitch;
    private float _yaw;
    private CharacterController _cc;
    private PlayerInput _playerInput;
    private InputAction _moveAction;
    private InputAction _lookAction;
    private Vector3 _velocity;

    void Awake()
    {
        _cc = GetComponent<CharacterController>();
        _playerInput = GetComponent<PlayerInput>();
        _moveAction = _playerInput.actions.FindAction("Move");
        _lookAction = _playerInput.actions.FindAction("Look");
        Cursor.lockState = CursorLockMode.Locked;
    }

    // LateUpdate je klíčový pro kameru - provede se až POTÉ, co se hráč pohne
    void LateUpdate()
    {
        if (cameraPivot != null)
        {
            // Tímhle zajistíme, že kamera bude VŽDY koukat tam, kam chceme myší,
            // i kdyby se tělo hráče pod ní cukalo jakkoliv.
            cameraPivot.rotation = Quaternion.Euler(_pitch, _yaw, 0f);
        }
    }

    void Update()
    {
        if (_playerInput == null) return;

        // Pokud je otevřený inventář, nepokračuj v pohybu ani otáčení
        // (Předpokládáme, že máš někde referenci na ten panel nebo stav)
        if (Keyboard.current.tabKey.isPressed)
        {
            Cursor.lockState = CursorLockMode.None; // Uvolní myš
            return;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked; // Zamkne myš zpět pro hraní
        }

        // --- 1. ČTENÍ VSTUPŮ ---
        Vector2 look = _lookAction.ReadValue<Vector2>();
        Vector2 moveInput = _moveAction.ReadValue<Vector2>();

        // --- 2. ROTACE MYŠÍ ---
        _yaw += look.x * mouseSensitivity;
        _pitch = Mathf.Clamp(_pitch - look.y * mouseSensitivity, minPitch, maxPitch);

        // --- 3. VÝPOČET SMĚRU POHYBU ---
        // Vytvoříme směr relativně k pohledu (yaw), ale bez vlivu modelu
        Vector3 camForward = Quaternion.Euler(0, _yaw, 0) * Vector3.forward;
        Vector3 camRight = Quaternion.Euler(0, _yaw, 0) * Vector3.right;

        Vector3 moveDir = (camForward * moveInput.y + camRight * moveInput.x).normalized;

        // --- 4. OTÁČENÍ MODELU (Ten "zásek" opravujeme zde) ---
        if (moveInput.sqrMagnitude > 0.01f)
        {
            // Vytvoříme cílovou rotaci
            Quaternion targetRotation = Quaternion.LookRotation(moveDir);

            // Použijeme Slerp s pevnou rychlostí nezávislou na snímkování
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
        }

        // --- 5. POHYB A GRAVITACE ---
        if (_cc.isGrounded) _velocity.y = -2f;
        else _velocity.y -= gravity * Time.deltaTime;

        _cc.Move((moveDir * moveSpeed + _velocity) * Time.deltaTime);
    }
}