using UnityEngine;

public class PlayerStats : MonoBehaviour
{
    [Header("Health System")]
    public float maxHealth = 100f;
    public float currentHealth;

    [Header("Infection System")]
    public float infectionPercent = 0f; 
    public float infectionGrowthOverTime = 0.005f; 

    void Start()
    {
        currentHealth = maxHealth;
    }

    void Update()
    {
       
        if (infectionPercent < 100f)
        {
            infectionPercent += infectionGrowthOverTime * Time.deltaTime;
        }

       
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    public void TakeDamage(float amount, float infectionIncrease)
    {
        currentHealth -= amount;
        infectionPercent += infectionIncrease;
        Debug.Log($"Hit! HP: {currentHealth}, Infection: {infectionPercent}%");
    }

    void Die()
    {
        Debug.Log("Player is dead!");
       
        Time.timeScale = 0; 
    }
}