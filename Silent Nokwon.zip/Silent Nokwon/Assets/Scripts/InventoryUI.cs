using UnityEngine;
using TMPro; 
using UnityEngine.InputSystem;

public class InventoryUI : MonoBehaviour
{
    public GameObject inventoryPanel; 
    public TextMeshProUGUI itemDisplay; 
    public Inventory playerInventory; 

    void Update()
    {
      
        if (Keyboard.current.tabKey.wasPressedThisFrame)
        {
            OpenInventory();
        }

        if (Keyboard.current.tabKey.wasReleasedThisFrame)
        {
            CloseInventory();
        }
    }

    void OpenInventory()
    {
        inventoryPanel.SetActive(true);
        itemDisplay.text = "INVENTORY:\n";

        foreach (string itemName in playerInventory.items)
        {
            itemDisplay.text += "- " + itemName + "\n";
        }
    }

    void CloseInventory()
    {
        inventoryPanel.SetActive(false);
    }
}