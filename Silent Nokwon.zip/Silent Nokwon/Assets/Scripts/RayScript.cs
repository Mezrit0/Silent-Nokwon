using UnityEngine;
using UnityEngine.InputSystem;

public class RayScript : MonoBehaviour
{
    public float interactDist = 4f;
    public LayerMask interactMask;
    public float shootDistance = 50f;
    public float weaponDamage = 25f;
    public int currentAmmo = 7;

    void Update()
    {
        Ray ray = new Ray(transform.position, transform.forward);
        RaycastHit hit;

        Debug.DrawRay(transform.position, transform.forward * interactDist, Color.yellow);

        //  1. INTERACTION (E Key) 
       
        if (Keyboard.current != null && Keyboard.current.eKey.wasPressedThisFrame)
        {
            if (Physics.Raycast(ray, out hit, interactDist, interactMask))
            {
                Item item = hit.collider.GetComponent<Item>();
                if (item != null)
                {
                    item.Interact(transform.root.gameObject);
                }
                else
                {
                    Door door = hit.collider.GetComponentInParent<Door>();
                    if (door != null)
                    {
                        door.Interact(transform.root.GetComponent<Inventory>());
                    }
                }
            }
        }

        //  2. COMBAT (Left Mouse Button)
        if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
        {
            Shoot(ray);
        }
    }

  
    void Shoot(Ray ray)
    {
    
        if (currentAmmo <= 0)
        {
            Debug.Log("out ofammo");
            return;
        }

        currentAmmo--; 
        RaycastHit hit;
        Debug.Log("shots fired ammo left: " + currentAmmo);

       
        if (Physics.Raycast(ray, out hit, shootDistance))
        {
            Debug.Log("RayScript: Hit " + hit.collider.name);

            EnemyHealth enemy = hit.collider.GetComponent<EnemyHealth>();
            if (enemy != null)
            {
                enemy.TakeDamage(weaponDamage);
            }
        }
    }
}