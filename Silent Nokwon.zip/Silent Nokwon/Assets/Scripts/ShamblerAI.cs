using UnityEngine;
using UnityEngine.AI;

public class ShamblerAI : MonoBehaviour
{
    public Transform player;
    public float chaseRange = 15f;
    public float attackRange = 2f;
    public float damage = 15f;
    public float infectionIncrease = 10f;
    public float attackCooldown = 2f;

    private NavMeshAgent _agent;
    private float _nextAttackTime;

    void Start()
    {
        _agent = GetComponent<NavMeshAgent>();
      
        if (player == null) player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    void Update()
    {
        float distance = Vector3.Distance(transform.position, player.position);

        if (distance <= chaseRange)
        {
            _agent.SetDestination(player.position);

            if (distance <= attackRange && Time.time >= _nextAttackTime)
            {
                Attack();
                _nextAttackTime = Time.time + attackCooldown;
            }
        }
    }

    void Attack()
    {
        PlayerStats stats = player.GetComponent<PlayerStats>();
        if (stats != null)
        {
            stats.TakeDamage(damage, infectionIncrease);
            Debug.Log("Shambler attacked");
        }
    }
}