using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.HighDefinition;

public class InfectionVFX : MonoBehaviour
{
    [Header("References")]
    public PlayerStats playerStats;
    public Volume globalVolume;

    [Header("Infection Settings")]
    public float infectionThreshold = 50f;

    [Header("Health Settings")]
    public float healthBlurThreshold = 30f; 

    [Header("Visual Intensity")]
    public float maxBlurIntensity = 10f;

    private DepthOfField _dof;

    void Start()
    {
        if (globalVolume.profile.TryGet<DepthOfField>(out _dof))
        {
            Debug.Log("InfectionVFX: Ready to blur vision.");
        }
    }

    void Update()
    {
        if (playerStats == null || _dof == null) return;

        // 1. Calculate blur from Infection (50% to 100%)
        float infectionFactor = Mathf.InverseLerp(infectionThreshold, 100f, playerStats.infectionPercent);

        // 2. Calculate blur from Health (30% down to 0%)
        // We use 1 - InverseLerp because we want intensity to GO UP as HP GOES DOWN
        float healthFactor = 1f - Mathf.InverseLerp(0f, healthBlurThreshold, playerStats.currentHealth);
        healthFactor = Mathf.Clamp01(healthFactor);

        // 3. Take the strongest effect (so they don't just stack weirdly)
        float finalIntensity = Mathf.Max(infectionFactor, healthFactor);

        // 4. Apply to Depth of Field
        if (finalIntensity > 0)
        {
            _dof.nearFocusEnd.value = finalIntensity * maxBlurIntensity;
            _dof.nearFocusStart.value = finalIntensity * (maxBlurIntensity * 0.5f);
        }
        else
        {
            _dof.nearFocusEnd.value = 0f;
            _dof.nearFocusStart.value = 0f;
        }
    }
}