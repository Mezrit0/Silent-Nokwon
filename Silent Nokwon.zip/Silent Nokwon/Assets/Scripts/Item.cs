using UnityEngine;

public class Item : MonoBehaviour
{
    public string itemName;

    public virtual void Interact(GameObject player)
    {
        
        Inventory inv = player.GetComponent<Inventory>();

        if (inv != null)
        {
            inv.AddItem(itemName); 
            Destroy(gameObject);   
        }
    }
}