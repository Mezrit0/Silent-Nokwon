using UnityEngine;
using UnityEngine.InputSystem;

public class FlashlightController : MonoBehaviour
{
    public GameObject flashlightObject;
    private bool _isOn = true;

    void Update()
    {
     
        if (Keyboard.current.fKey.wasPressedThisFrame)
        {
            ToggleFlashlight();
        }
    }

    void ToggleFlashlight()
    {
        _isOn = !_isOn; 
        flashlightObject.SetActive(_isOn);
    }
}