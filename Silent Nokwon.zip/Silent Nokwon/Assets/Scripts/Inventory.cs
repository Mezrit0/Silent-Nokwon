using UnityEngine;
using System.Collections.Generic; 

public class Inventory : MonoBehaviour
{

    public List<string> items = new List<string>();

 
    public void AddItem(string itemName)
    {
        items.Add(itemName);
        Debug.Log("Inventory: Added " + itemName);
    }

    public bool HasItem(string itemName)
    {
        return items.Contains(itemName);
    }
}