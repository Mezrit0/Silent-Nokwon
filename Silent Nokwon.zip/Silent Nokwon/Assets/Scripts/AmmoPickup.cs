using UnityEngine;

public class AmmoPickup : Item
{
    public int ammoAmount = 7;

    public override void Interact(GameObject player)
    {
        
        RayScript weapon = player.GetComponentInChildren<RayScript>();

        if (weapon != null)
        {
            weapon.currentAmmo += ammoAmount;
            Debug.Log("Ammo collected" + weapon.currentAmmo);
            Destroy(gameObject);
        }
    }
}