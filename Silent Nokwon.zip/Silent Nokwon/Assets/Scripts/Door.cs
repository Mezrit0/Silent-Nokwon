using UnityEngine;

public class Door : MonoBehaviour
{
    [Header("Settings")]
    public string requiredItem = "Key";
    public float openAngle = 90f;
    public float smoothing = 2f;

    private bool _isOpen = false;
    private Quaternion _closedRotation;
    private Quaternion _openRotation;
    private Quaternion _targetRotation;
    private bool _isMoving = false;

    void Awake()
    {
     
        _closedRotation = transform.rotation;

        
        _openRotation = _closedRotation * Quaternion.Euler(0, openAngle, 0);

        _targetRotation = _closedRotation;
    }

    public void Interact(Inventory inventory)
    {
        // check key
        if (!_isOpen && inventory != null)
        {
            if (!inventory.HasItem(requiredItem))
            {
                Debug.Log("closed, you need: " + requiredItem);
                return;
            }
        }

        _isOpen = !_isOpen;
        _isMoving = true;

        if (_isOpen)
        {
            _targetRotation = _openRotation;
            Debug.Log("opening");
        }
        else
        {
            _targetRotation = _closedRotation;
            Debug.Log("closing");
        }
    }

    void Update()
    {
        if (_isMoving)
        {
            
            transform.rotation = Quaternion.Slerp(transform.rotation, _targetRotation, Time.deltaTime * smoothing);

            if (Quaternion.Angle(transform.rotation, _targetRotation) < 0.1f)
            {
                transform.rotation = _targetRotation;
                _isMoving = false;
            }
        }
    }
}